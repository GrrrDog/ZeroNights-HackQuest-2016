package org.zeronights.justiceleaguedb.domains;

public class Criminal {
	private String nickname;
	
	
	public Criminal(String string) {
		this.nickname=string;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}


}
