package org.zeronights.justiceleaguedb.services;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.zeronights.justiceleaguedb.domains.Criminal;

@Service
public class CriminalService {
	private ArrayList<Criminal> criminalDB = new ArrayList<Criminal>();

	private static final Logger logger = LoggerFactory.getLogger(CriminalService.class);

	public CriminalService() {

		criminalDB.add(new Criminal("Loki"));

		criminalDB.add(new Criminal("Magneto"));

	}

	public void add�riminal(Criminal newCriminal) {
		criminalDB.add(newCriminal);
		logger.info("�riminal is added");
	}

	public ArrayList<Criminal> findAll() {
		return criminalDB;
	}

}
