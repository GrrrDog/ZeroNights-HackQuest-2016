package org.zeronights.justiceleaguedb.domains;

public class Command {
	private String cmd_name;

	public Command(String string) {
		this.cmd_name=string;
	}

	public String getName() {
		return cmd_name;
	}

	public void setName(String name) {
		this.cmd_name = name;
	}

}
