package org.zeronights.justiceleague.domains;

public class User {

	private String username;
	private String password;
	private Boolean isSupaAdministrata;
	private String email;
	private String answer;

	public User(String username, String password, Boolean isSupaAdministrata, String email, String answer) {
		this.username = username;
		this.password = password;
		this.isSupaAdministrata = isSupaAdministrata;
		this.email = email;
		this.answer = answer;
	}

	
	public User() {

	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getIsSupaAdministrata() {
		return isSupaAdministrata;
	}

	public void setIsSupaAdministrata(Boolean isSupaAdministrata) {
		this.isSupaAdministrata = isSupaAdministrata;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", isSupaAdministrata=" + isSupaAdministrata + ", email=" + email
				+ ", answer=" + answer + "]";
	}

}
