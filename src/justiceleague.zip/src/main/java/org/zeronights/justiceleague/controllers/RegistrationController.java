package org.zeronights.justiceleague.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.zeronights.justiceleague.domains.User;
import org.zeronights.justiceleague.services.UserService;

@Controller
public class RegistrationController {
	private static final Logger logger = LoggerFactory.getLogger(RegistrationController.class);
	@Autowired
	private UserService userService;

	@RequestMapping(value = "/registration", method = RequestMethod.GET)
	public String registrationViewHandler() {
//		logger.info("Welcome registration ! ");
		return "registration";
	}

	@RequestMapping(value = "/registration", method = RequestMethod.POST)
	public String registrationHandler(User user, @RequestParam String repassword, Model model) {

		if (user.getUsername() == null || user.getUsername().equals("")) {
			model.addAttribute("error", "Please, enter your name");
			return "registration";
		}
		if (user.getPassword() == null || user.getPassword().length()<8) {
			model.addAttribute("error", "Password has to be at least 8 symbols");
			return "registration";
		}
		if (user.getAnswer() == null || user.getAnswer().equals("")) {
			model.addAttribute("error", "Please, enter your answer");
			return "registration";
		}
		if (user.getEmail() == null || user.getEmail().equals("")) {
			model.addAttribute("error", "Please, enter your email");
			return "registration";
		}
		if (userService.findByName(user.getUsername()) != null) {
			model.addAttribute("error", "The username is already in use");
			return "registration";
		}
		
		if (userService.findByName(user.getUsername()) != null) {
			model.addAttribute("error", "The username is already in use");
			return "registration";
		}
		
		if (!user.getPassword().equals(repassword)) {
			model.addAttribute("error", "Password doesn't equal the retype password");
			return "registration";
		}
		

		logger.info("Successeful registration ! " + user);
		userService.addUser(user);

		model.addAttribute("message", "Your registration is complete! Now you can sign in!");
		return "success";
	}
}
