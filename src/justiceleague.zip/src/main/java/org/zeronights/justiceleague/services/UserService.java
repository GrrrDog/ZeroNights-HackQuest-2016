package org.zeronights.justiceleague.services;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.zeronights.justiceleague.domains.User;

@Service
public class UserService {

	private ArrayList<User> userDB = new ArrayList<User>();

	private static final Logger logger = LoggerFactory.getLogger(UserService.class);

	public UserService() {
		User newUser1 = new User("admin", "paravarka", true, "admin@zeronights.org", "morkovnii");
		User newUser2 = new User("user", "tarashaka", false, "user@zeronights.org", "lozurnii");

		userDB.add(newUser1);
		userDB.add(newUser2);
	}

	public void addUser(User newUser) {

		if (newUser.getIsSupaAdministrata() == null) {
			newUser.setIsSupaAdministrata(false);
		}
		userDB.add(newUser);
		logger.info("User is created");
	}

	public void updateUser(User user) {
		// stupid protection against spoiling admin account with spring
		// autobinding vuln
		Boolean isSupaAdministrata = false;
		for (int i = 0; i < userDB.size(); i++) {
			if (userDB.get(i).getUsername().equals(user.getUsername())) {
				if (userDB.get(i).getIsSupaAdministrata()) {
					isSupaAdministrata = true;
				}
				logger.info("User is found");
				userDB.remove(i);
			}
		}
		user.setIsSupaAdministrata(isSupaAdministrata);
		userDB.add(user);
		System.out.println("User is updated");
	}

	public User findByName(String name) {
		for (int i = 0; i < userDB.size(); i++) {
			// logger.info("userDB.size() " + i);
			// logger.info("name " + name);
			// logger.info("get name " + userDB.get(i).getUsername());
			// logger.info("get password " + userDB.get(i).getPassword());

			if (userDB.get(i).getUsername().equals(name)) {
				logger.info("User is found");

				return userDB.get(i);
			}
		}
		logger.info("User is not found");
		return null;
	}

	public User findByNamePassword(String name, String password) {

		for (int i = 0; i < userDB.size(); i++) {
			// logger.info("userDB.size() " + i);
			// logger.info("name " + name);
			// logger.info("password " + password);
			// logger.info("get name " + userDB.get(i).getUsername());
			// logger.info("get password " + userDB.get(i).getPassword());

			if (userDB.get(i).getUsername().equals(name) && userDB.get(i).getPassword().equals(password)) {
				logger.info("User is found");

				return userDB.get(i);
			}
		}
		logger.info("User is not found");
		return null;
	}

}
