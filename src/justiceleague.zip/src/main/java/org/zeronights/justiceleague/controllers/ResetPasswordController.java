package org.zeronights.justiceleague.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.zeronights.justiceleague.domains.User;
import org.zeronights.justiceleague.services.UserService;
import org.zeronights.justiceleague.utils.GeneratePassword;

@Controller
@SessionAttributes("user")
public class ResetPasswordController {

	private static final Logger logger = LoggerFactory.getLogger(ResetPasswordController.class);

	@Autowired
	private UserService userService;

	@RequestMapping(value = "/reset", method = RequestMethod.GET)
	public String resetViewHandler() {
		logger.info("Welcome reset ! ");
		return "reset";
	}

	@RequestMapping(value = "/reset", method = RequestMethod.POST)
	public String resetHandler(@RequestParam String username, Model model) {
		logger.info("Checking username " + username);
		User user = userService.findByName(username);

		if (user == null) {
			logger.info("there is no user with name " + username);
			model.addAttribute("error", "Username is not found");
			return "reset";
		}
		model.addAttribute("user", user);

		return "redirect:resetQuestion";
	}

	@RequestMapping(value = "/resetQuestion", method = RequestMethod.GET)
	public String resetViewQuestionHandler(@ModelAttribute User user) {
		logger.info("Welcome resetQuestion ! " + user);
		return "resetQuestion";
	}

	@RequestMapping(value = "/resetQuestion", method = RequestMethod.POST)
	public String resetQuestionHandler(@RequestParam String answerReset, SessionStatus status,
			User user, Model model) {
		logger.info("Checking resetQuestion ! " + answerReset + " for " + user);

		if (!user.getAnswer().equals(answerReset)) {
			logger.info("Answer in db " + user.getAnswer() + " Answer " + answerReset);
			model.addAttribute("error", "Incorrect answer");
			return "resetQuestion";
		}

		status.setComplete();
		String newPassword = GeneratePassword.generatePassowrd(10);
		user.setPassword(newPassword);
		userService.updateUser(user);

		model.addAttribute("message", "Your new password is " + newPassword);
		return "success";

	}
}
